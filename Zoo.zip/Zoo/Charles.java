import java.util.concurrent.TimeUnit;
/**
 * Abstract class Pigeon - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public class Charles extends Researchers implements DungeonChambers
{

    /**
     * Construction for objects of class moblin
     */
    public Charles()
    {
        this("Charles (Mr. G-Dawg)" , "Appearantly not great at his job in security");
    }
    public Charles(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String job()
    {
        return "Head Security Officer - Dungeon Chambers";
    }
    
    @Override
    public String talkTo() throws InterruptedException
    {
        System.out.println("''If only there was a security career that involved sitting around for hours on end''");
        delayDots(3);
        return "";
    }
    
    @Override
    public String dungeon() throws InterruptedException
    {
        System.out.println("''This area is flooded with powerful and dangerous monsters- It's not safe to go alone \n");
        delayDots(3);
        System.out.print("''Take this''");
        delayDots(3);
        return "";
    }
    
    
}
