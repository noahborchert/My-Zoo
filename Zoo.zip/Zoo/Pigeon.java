
/**
 * Abstract class Pigeon - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public class Pigeon extends Animal implements Flying, FalconryTower
{

    /**
     * Construction for objects of class Pigeon
     */
    public Pigeon()
    {
        this("Peter Parker the Poignant Pigeon" , "I could fly, but I prefer to swing");
    }
    public Pigeon(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "The flesh of my foes";
    }
    @Override
    public String makeNoise()
    {
        return "Skwa - swoosh";
    }
    @Override
    public String fly()
    {
        return "*swinging on the ceiling*";
    }
    @Override
    public String tower()
    {
        return "using his...webs?...to swing about the edge of the tower roof";
    }
    
}
