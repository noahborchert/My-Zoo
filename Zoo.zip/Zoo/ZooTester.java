import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.Random;
import java.util.Scanner;
import java.util.*;
/**
 * Write a description of class ZooTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ZooTester
{
    public static int money;
    public static int randMoney;
    public static int playerHp = 50;
    public static int playerDmg;
    public static int animalHp;
    public static int animalDmg;
    public static boolean holyHandGrenade;
    public static void main(String[] args) throws InterruptedException
    {
        List<Animal> allMyAnimals = new ArrayList<Animal>();
        List<Researchers> allMyEmployees = new ArrayList<Researchers>();
        System.out.println();

        System.out.print("Finally you reach a clearing in the forest");
        delayDots(3);
        System.out.print("Ahead is a blinding light");
        delayDots(3);
        System.out.println();
        System.out.print("You step through this veil of light, and finally");
        delayDots(3);
        System.out.println("Your gaze rises to meet the first sign of civilization you've ");
        System.out.print("come across in your months of travel");
        delayDots(3);
        System.out.println();
        System.out.print("Welcome, brave adventurer to");
        delayDots(3);
        System.out.println("\n \n");

        System.out.println("      ██████╗ ███████╗ ██████╗██╗   ██╗██╗     ██╗ █████╗ ██████╗"); 
        System.out.println("      ██╔══██╗██╔════╝██╔════╝██║   ██║██║     ██║██╔══██╗██╔══██╗");
        System.out.println("      ██████╔╝█████╗  ██║     ██║   ██║██║     ██║███████║██████╔╝");
        System.out.println("      ██╔═══╝ ██╔══╝  ██║     ██║   ██║██║     ██║██╔══██║██╔══██╗");
        System.out.println("      ██║     ███████╗╚██████╗╚██████╔╝███████╗██║██║  ██║██║  ██║");
        System.out.println("      ╚═╝     ╚══════╝ ╚═════╝ ╚═════╝ ╚══════╝╚═╝╚═╝  ╚═╝╚═╝  ╚═╝");
        System.out.println("*+*====================================================================*+*");
        System.out.println("");
        System.out.println("");
        System.out.println("                                  _____                                                               ");
        System.out.println("                               .-       `-.   ,                                                     ");
        System.out.println("                             .'            './j\\                              ");
        System.out.println("                            /               /:/#\\                /\\           ");
        System.out.println("                           ;              ,/' '/#\\              //#\\          ");
        System.out.println("                           |            /'/:   '/#\\            /  /#\\         ");
        System.out.println("                           :        ,  /'/'     '/#\\__..----_ /    /#\\      ");
        System.out.println("                            \\       /'\'-._:__    '/#\\;       /========\\");
        System.out.println("                            `-.   / ;#\']   ;   --./#J       ':____...!:'       "); 
        System.out.println("                               `-/   /#\\  J  [;[;[;Y]         |      ;        ");
        System.out.println("******---....             __.--*/     /#\\ ;   * *  |     !    |   #! |        ");
        System.out.println("             +*--.. _.--**     /      ,/#\'-..____.;_,   |     |   '  |        ");
        System.out.println("                   *-.        :_....___,/#) *####* | '_.-*,   | #['  |        ");
        System.out.println("                     '-._       |[;[;[;[;|         |.;'  /;\\  |      |        ");
        System.out.println("                          `-.   |        :     _   .;'    /;\\ |   #* |        ");
        System.out.println("                      !      `._:      _  ;   ##' .;'      /;\\|  _,  |        ");
        System.out.println("              .#\\***---..._    ';, |      .;{___     /;\\  ]#' |__....--       ");
        System.out.println("                     .--.      ;'/#\\         \\    ]! |       *| , ***--./_J    /  ");       
        System.out.println("                    /  '%;    /  '/#\\         \\   !' :        |!# #! #! #|    :`.__   ");   
        System.out.println("                   i__..'%] _:_   ;##J         \\      :*#...._!   '  *  *|__  |    `--.._");
        System.out.println("                    | .--*** !|****  |***----...J     | '##** `-._       |  ***---.._    ");
        System.out.println("                ____: |      #|      |         #|     |          *]      ;   ___...-*T,  ");
        System.out.println("               /   :  :      !|      |   _______!_    |           |__..--;***     ,;MM;  ");
        System.out.println("              :____| :    .-.#|      |  /\\      /#\\   |          /'               ''MM;  ");
        System.out.println("               |***: |   /   \\|   .----+  ;      /#\\  :___..--**;                  ,'MM; ");
        System.out.println("              _Y--:  |  ;     ;.-'      ;  \\______/#: /         ;                  ''MM; ");
        System.out.println("             /    |  | ;_______;     ____!  |*##***MM!         ;                    ,'MM;");
        System.out.println("            !_____|  |  |*#*#*|____.'**##*  |       :         ;                     ''MM  ");
        System.out.println("             | ****--!._|     |##**         !       !         :____.....-------^^^^^^ |'");
        System.out.println("             |          :     |______                        ___!_ *#**#**#***#***#***|  ");
        System.out.println("           __|          ;     |MM*MM*****---..._______...--**MM*MM]                   |   ");
        System.out.println("              *\\-.      :      |#                                 :                   |  ");
        System.out.println("               /#'.    |      /##,                                !                   |  ");
        System.out.println("             .',/'\\   |       #:#,                                ;       .==.        |  ");
        System.out.println("              /*\\'#*\',.|       ##;#,                              !     ,'||||',      |  ");
        System.out.println("                   /;/`:       ######,          ____             _:     M||||||M      |  ");
        System.out.println("                  ###          /;*\\.__*-._   ***                  |===..M!!!!!!M______|  ");
        System.out.println("                                     `--..`--.._____             _!_                    ");
        System.out.println("                                                   `--...____,=*_.'`-.____             ");
        System.out.println("");

        System.out.println("*> You reach the entrance of the giant manor. The cobble stone wall to the <*");
        System.out.println("*> right of the door, adorns a moss-covered plaque. You clean it enough to read: <*");
        System.out.println("");
        System.out.println("++=================================++");
        System.out.println("|| Prof. Oak's research center for || ");
        System.out.println("||    for peculiar creatures       ||");
        System.out.println("++=================================++");
        System.out.println("");
        System.out.println("*> Do you: <*");
        System.out.println("▷ Knock");
        System.out.println("▷ Enter");
        Scanner enter = new Scanner(System.in);
        String go = enter.nextLine(); 
        if(go.equals("Knock") || go.equals("knock"))
        {
            System.out.println("*> You grasp the giant brass ring held in the mouth of the menacing hippopotamus door knocker <*");
            System.out.print("Knock");
            delayDots(3);
            System.out.println();
            System.out.print("Knock");
            delayDots(4);
            System.out.println();
            System.out.print("Knock");
            delayDots(5);
            System.out.println();
            System.out.println("*> The door, propelled by some invisible force, swings wide open inwards following the eco of the third knock <*");
            System.out.println("*> You step inside <*");
        }
        else if(go.equals("Enter") || go.equals("enter"))
        {
            System.out.println("*> You reach to push open the door but, propelled by some invisible force, it swings wide open. <*");
            System.out.print("*> You enter");
            delayDots(3);
            System.out.print(" <*");
        }

        System.out.println("Loading");
        delayDots(3);
        System.out.println("Capturing creatures");
        populateAnimals(allMyAnimals);
        delayDots(3);
        System.out.println("Employing researchers");
        employResearchers(allMyEmployees);
        delayDots(3);

        System.out.println("*> With your eyes now fully adjusted to the dramatic change in lighting, you now find yourself standing <*");
        System.out.println("*> in the huge, extravagant guest waiting hall <*");

        System.out.println("*> You scan the room once or twice and decide to: <*");
        System.out.println();
        System.out.println("▷ Enter Prof. Oak's study");
        System.out.println("▷ Explore the castle forward");
        System.out.println("▷ View the animals' feeding habits");
        System.out.println("▷ Turn on the intercom");
        System.out.println("▷ Open the Zoo Encyclopedia");
        System.out.println("▷ Visit employee hall of fame");
        System.out.println("▷ Leave");
        System.out.println("");

        Scanner in = new Scanner(System.in);
        String text = in.nextLine();

        String msg = "";
        while(!text.equals("This game is garbonzo beans"))
        {
            switch(text)
            {
                case "help":
                msg = "There is no help for those who enter this place";
                break;

                case "Enter Prof. Oak's study":
                msg = oakStudy(allMyAnimals);
                break;

                case "Explore the castle forward":
                msg = exploreEnclosures(allMyAnimals);
                break;

                case "View the animals' feeding habits":
                msg = feedingHabits(allMyAnimals);
                break;

                case "Turn on the intercom":
                msg = intercomOn(allMyAnimals);
                break;

                case "Open the Zoo Encyclopedia":
                msg = zooBook(allMyAnimals);
                break;

                case "Visit employee hall of fame":
                msg = employeeHall(allMyEmployees);
                break;

                case "Leave":
                msg = "*>You grasp the doorknob to leave, but the door is locked...there is no way out now...Unless you speak the truth<*";
                break;

                default : msg = "You flail helplessly with indecision";
            }

            System.out.println(msg);
            delayDots(3);
            System.out.println("++====================================++");
            System.out.println("||                                    ||");
            System.out.println("||  What would you like to do next?   ||");
            System.out.println("||                                    ||");
            System.out.println("++====================================++");
            text = in.nextLine();

        }
        System.out.println("How...did you know....");
        System.out.println("You've seen right through the pomp and frills, and know this game for what it truely is...");
        System.out.println("You have acended and may now leave");
        delayDots(3);
        System.out.print("\n");
        System.out.print("Fare well, adventurer");
        delayDots(3);
    }

    public static void delayDots(int dotAmount) throws InterruptedException
    {
        for(int i=0; i<dotAmount; i++)
        {
            TimeUnit.MILLISECONDS.sleep(350);
            System.out.print(".");
        }
        TimeUnit.MILLISECONDS.sleep(350);
        System.out.println();
    }

    public static void delayDots() throws InterruptedException
    {
        delayDots(0);
    }

    public static void delayClock() throws InterruptedException
    {

        System.out.println("Waiting for midday");
        TimeUnit.SECONDS.sleep(1);
        System.out.print("⏳");
        TimeUnit.SECONDS.sleep(1);
        System.out.print("⏳");
        TimeUnit.SECONDS.sleep(1);
        System.out.print("⏳ \n");
        TimeUnit.SECONDS.sleep(1);

    }

    public static void populateAnimals(List<Animal> animals)
    {
        Bokoblin a1 = new Bokoblin();
        animals.add(a1);

        Moblin a2 = new Moblin();
        animals.add(a2);

        Lizalfo a3 = new Lizalfo();
        animals.add(a3);

        FleshMonster a4 = new FleshMonster();
        animals.add(a4);

        Droid a5 = new Droid();
        animals.add(a5);

        Vince a6 = new Vince();
        animals.add(a6);

        Llama a7 = new Llama();
        animals.add(a7);

        Phish a8 = new Phish();
        animals.add(a8);

        Platypus a9 = new Platypus();
        animals.add(a9);

        Walter a10 = new Walter();
        animals.add(a10);

        Pigeon a11 = new Pigeon();
        animals.add(a11);

        Shark a12 = new Shark();
        animals.add(a12);

        LR57CombatDroid a13 = new LR57CombatDroid();
        animals.add(a13);

        Duck a14 = new Duck();
        animals.add(a14);

        Megalodon a15 = new Megalodon();
        animals.add(a15);

        SunBear a16 = new SunBear();
        animals.add(a16);

        Trex a17 = new Trex();
        animals.add(a17);

        Abominablesnowman a18 = new Abominablesnowman();
        animals.add(a18);

        Lochnessmonster a19 = new Lochnessmonster();
        animals.add(a19);

        MourningDove a20 = new MourningDove();
        animals.add(a20);

        Bunny a21 = new Bunny();
        animals.add(a21);

        FruitBat a22 = new FruitBat();
        animals.add(a22);

        IronTarkus a23 = new IronTarkus();
        animals.add(a23);

        GoldFish a24 = new GoldFish();
        animals.add(a24);

        Bella a25 = new Bella();
        animals.add(a25);

        Thwomp a26 = new Thwomp();
        animals.add(a26);

        Rhino a27 = new Rhino();
        animals.add(a27);

        Goomba a28 = new Goomba();
        animals.add(a28);

        Anaconda a29 = new Anaconda();
        animals.add(a29);

        RedPanda a30 = new RedPanda();
        animals.add(a30);

        Bigfoot a31 = new Bigfoot();
        animals.add(a31);

        RedCrowCrane a32 = new RedCrowCrane();
        animals.add(a32);

        HomunculusFleshPuppet a33 = new HomunculusFleshPuppet();
        animals.add(a33);
    }

    public static void employResearchers(List<Researchers> researchers)
    {
        Charles z1 = new Charles();
        researchers.add(z1);

        Ron z2 = new Ron();
        researchers.add(z2);

        Betty z3 = new Betty();
        researchers.add(z3);

        Vincent z4 = new Vincent();
        researchers.add(z4);
    }

    public static String oakStudy(List<Animal> animals) throws InterruptedException
    {

        String msg = "";

        System.out.println("");
        System.out.print("*> As you enter the study, you are immediately greeted by the cold remains of Prof. Oak <* \n");
        delayDots(3);
        System.out.println("                            ...----....");
        System.out.println("                      ..-:'''         '''-..");
        System.out.println("                   .-'                      '-.");
        System.out.println("                 .'              .     .       '.");
        System.out.println("               .'   .          .    .      .    .''.");
        System.out.println("             .'  .    .       .   .   .     .   . ..:.");
        System.out.println("            .' .   . .  .       .   .   ..  .   . ....::.");
        System.out.println("          ..   .   .      .  .    .     .  ..  . ....:IA.");
        System.out.println("         .:  .   .    .    .  .  .    .. .  .. .. ....:IA.");
        System.out.println("        .: .   .   ..   .    .     . . .. . ... ....:.:VHA.");
        System.out.println("        '..  .  .. .   .       .  . .. . .. . .....:.::IHHB.");
        System.out.println("       .:. .  . .  . .   .  .  . . . ...:.:... .......:HIHMM.");
        System.out.println("      .:.... .   . .'::''.. .   .  . .:.:.:II;,. .. ..:IHIMMA");
        System.out.println("      ':.:..  ..::IHHHHHI::. . .  ...:.::::.,,,. . ....VIMMHM");
        System.out.println("     .:::I. .AHHHHHHHHHHAI::. .:...,:IIHHHHHHMMMHHL:. . VMMMM");
        System.out.println("    .:.:V.:IVHHHHHHHMHMHHH::..:'' .:HIHHHHHHHHHHHHHMHHA. .VMMM.");
        System.out.println("    :..V.:IVHHHHHMMHHHHHHHB... . .:VPHHMHHHMMHHHHHHHHHAI.:VMMI");
        System.out.println("    ::V..:VIHHHHHHMMMHHHHHH. .   .I':IIMHHMMHHHHHHHHHHHAPI:WMM");
        System.out.println("    ::'. .:.HHHHHHHHMMHHHHHI.  . .:..I:MHMMHHHHHHHHHMHV:':H:WM");
        System.out.println("    :: . :.::IIHHHHHHMMHHHHV  .ABA.:.:IMHMHMMMHMHHHHV:'. .IHWW");
        System.out.println("    '.  ..:..:.:IHHHHHMMHV' .AVMHMA.:.'VHMMMMHHHHHV:' .  :IHWV");
        System.out.println("     :.  .:...:'.:.:TPP'   .AVMMHMMA.:. 'VMMHHHP.:... .. :IVAI");
        System.out.println("    .:.   '... .:''   .   ..HMMMHMMMA::. .'VHHI:::....  .:IHW'");
        System.out.println("    ...  .  . ..:IIPPIH: ..HMMMI.MMMV:I:.  .:ILLH:.. ...:I:IM");
        System.out.println("  : .   .''' .:.V'. .. .  :HMMM:IMMMI::I. ..:HHIIPPHI::'.P:HM.");
        System.out.println("  :.  .  .  .. ..:.. .    :AMMM IMMMM..:...:IV':T::I::.'.:IHIMA");
        System.out.println("  'V:.. .. . .. .  .  .   'VMMV..VMMV :....:V:.:..:....::IHHHMH");
        System.out.println("    'IHH:.II:.. .:. .  . . . ' :HB'' . . ..PI:.::.:::..:IHHMMV'");
        System.out.println("     :IP''HHII:.  .  .    . . .'V:. . . ..:IH:.:.::IHIHHMMMMM'");
        System.out.println("     :V:. VIMA:I..  .     .  . .. . .  .:.I:I:..:IHHHHMMHHMMM");
        System.out.println("     :'VI:.VWMA::. .:      .   .. .:. ..:.I::.:IVHHHMMMHMMMMI");
        System.out.println("     :.'VIIHHMMA:.  .   .   .:  .:.. . .:.II:I:AMMMMMMHMMMMMI");
        System.out.println("     :..VIHIHMMMI...::.,:.,:!'I:!'I!'I!'V:AI:VAMMMMMMHMMMMMM'");
        System.out.println("     ':.:HIHIMHHA:'!!'I.:AXXXVVXXXXXXXA:.'HPHIMMMMHHMHMMMMMV");
        System.out.println("       V:H:I:MA:W'I :AXXXIXII:IIIISSSSSSXXA.I.VMMMHMHMMMMMM");
        System.out.println("         'I::IVA ASSSSXSSSSBBSBMBSSSSSSBBMMMBS.VVMMHIMM'''");
        System.out.println("          I:: VPAIMSSSSSSSSSBSSSMMBSSSBBMMMMXXI:MMHIMMI");
        System.out.println("         .I::. 'H:XIIXBBMMMMMMMMMMMMMMMMMBXIXXMMPHIIMM'");
        System.out.println("         :::I.  ':XSSXXIIIIXSSBMBSSXXXIIIXXSMMAMI:.IMM");
        System.out.println("         :::I:.  .VSSSSSISISISSSBII:ISSSSBMMB:MI:..:MM");
        System.out.println("         ::.I:.  ':'SSSSSSSISISSXIIXSSSSBMMB:AHI:..MMM.");
        System.out.println("         ::.I:. . ..:'BBSSSSSSSSSSSSBBBMMMB:AHHI::.HMMI");
        System.out.println("         :..::.  . ..::':BBBBBSSBBBMMMB:MMMMHHII::IHHMI");
        System.out.println("         ':.I:... ....:IHHHHHMMMMMMMMMMMMMMMHHIIIIHMMV'");
        System.out.println("           'V:. ..:...:.IHHHMMMMMMMMMMMMMMMMHHHMHHMHP'");
        System.out.println("            ':. .:::.:.::III::IHHHHMMMMMHMHMMHHHHM'");
        System.out.println("              '::....::.:::..:..::IIIIIHHHHMMMHHMV'");
        System.out.println("                '::.::.. .. .  ...:::IIHHMMMMHMV'");
        System.out.println("                  'V::... . .I::IHHMMV''");
        System.out.println("                    ''VHVHHHAHHHHMMV:''");

        System.out.println("*> Professor Oak lay stone-dead on his desk clutching a journal with the title ''Oak's research'' <*");
        System.out.println("*> You pry the book out of his dead, locked up fingers and begin to read <* \n");
        System.out.println("Prelude:");
        System.out.println("''I have come to discover hundreds of new, radically perculiar species over my extensive years of research");
        System.out.println("and have documented each finding in this journal. I pray the finding disclosed in this journal do good to the");
        System.out.println("poor soul that has entered this accursed project.''" + "\n" );
        System.out.print("flipping page");
        delayDots(3);
        System.out.println();
        System.out.println("Findings: \n");

        for(Animal a : animals)
        {
            msg += a.getName() + ": \n         " + a.getDescription() + "\n";
        }

        System.out.println(msg);
        System.out.println("*> At the bottom of the last written page of the notebook is a sloppily written, ink-blotted chicken scratch reading: <*");
        System.out.println("''They have all escaped....arm yourself well''");

        System.out.println("*>On the crowded shelf next to the desk, a small tape stands out to you<* \n");

        oldTape(animals);

        System.out.println("*>Before you leave the study, you see a small leather pouch.<*");

        foundMoney();
        if(randMoney >= 1)
        {
            System.out.println("*>You open it to find " + randMoney + " gold pieces inside.<*");
            System.out.println("*>Your wallet now currently holds " + money +" gold <*");
        }
        else
        {
            System.out.println("*>However, there is nothing but lint inside<*");
        }
        delayDots(3);
        System.out.println("*>You exit the study<*");
        delayDots(3);
        return "";
    }

    public static int foundMoney()
    {

        int min = 1;
        int max = 35;
        int range = max - min + 1;
        randMoney = (int)(Math.random() * range);
        money = randMoney + money;

        return money;
    }

    public static String feedingHabits(List<Animal> animals) throws InterruptedException
    {
        String msg = "";
        delayClock();
        System.out.println("");
        System.out.println("*>It's now midday. You find the massive feeding den and watch<*");
        System.out.println("*>all the animals in the zoo behind plexi glass as they feast.<* \n");
        System.out.println("/n");

        for(Animal a : animals)
        {
            msg += a.getName() + ": \n" + "eating:" + a.eat() + "\n" + "\n";
        }
        return msg;
    }

    public static String employeeHall(List<Researchers> researchers) throws InterruptedException
    {
        String msg = "";
        System.out.println("*>You walk down a corridor into a small, rectangular room with four plaques");
        System.out.println("hanging on the wall opposite to you.<* \n" + "\n");

        for(Researchers r : researchers)
        {
            msg += "||  " + r.getName() + ":  \n" + "||  " + r.job() + "\n" + "||  " + r.talkTo();
        }

        return msg;
    }

    public static String humuncTitle() throws InterruptedException
    {
        System.out.println(" ██░ ██  ▒█████   ███▄ ▄███▓ █    ██  ███▄    █  ▄████▄   █    ██  ██▓     █    ██   ██████      █████▒██▓    ▓█████   ██████  ██░ ██ ");
        System.out.println("▓██░ ██▒▒██▒  ██▒▓██▒▀█▀ ██▒ ██  ▓██▒ ██ ▀█   █ ▒██▀ ▀█   ██  ▓██▒▓██▒     ██  ▓██▒▒██    ▒    ▓██   ▒▓██▒    ▓█   ▀ ▒██    ▒ ▓██░ ██▒");
        System.out.println("▒██▀▀██░▒██░  ██▒▓██    ▓██░▓██  ▒██░▓██  ▀█ ██▒▒▓█    ▄ ▓██  ▒██░▒██░    ▓██  ▒██░░ ▓██▄      ▒████ ░▒██░    ▒███   ░ ▓██▄   ▒██▀▀██░");
        System.out.println("░▓█ ░██ ▒██   ██░▒██    ▒██ ▓▓█  ░██░▓██▒  ▐▌██▒▒▓▓▄ ▄██▒▓▓█  ░██░▒██░    ▓▓█  ░██░  ▒   ██▒   ░▓█▒  ░▒██░    ▒▓█  ▄   ▒   ██▒░▓█ ░██ ");
        System.out.println("░▓█▒░██▓░ ████▓▒░▒██▒   ░██▒▒▒█████▓ ▒██░   ▓██░▒ ▓███▀ ░▒▒█████▓ ░██████▒▒▒█████▓ ▒██████▒▒   ░▒█░   ░██████▒░▒████▒▒██████▒▒░▓█▒░██▓");
        System.out.println(" ▒ ░░▒░▒░ ▒░▒░▒░ ░ ▒░   ░  ░░▒▓▒ ▒ ▒ ░ ▒░   ▒ ▒ ░ ░▒ ▒  ░░▒▓▒ ▒ ▒ ░ ▒░▓  ░░▒▓▒ ▒ ▒ ▒ ▒▓▒ ▒ ░    ▒ ░   ░ ▒░▓  ░░░ ▒░ ░▒ ▒▓▒ ▒ ░ ▒ ░░▒░▒");
        System.out.println(" ▒ ░▒░ ░  ░ ▒ ▒░ ░  ░      ░░░▒░ ░ ░ ░ ░░   ░ ▒░  ░  ▒   ░░▒░ ░ ░ ░ ░ ▒  ░░░▒░ ░ ░ ░ ░▒  ░ ░    ░     ░ ░ ▒  ░ ░ ░  ░░ ░▒  ░ ░ ▒ ░▒░ ░");
        System.out.println(" ░  ░░ ░░ ░ ░ ▒  ░      ░    ░░░ ░ ░    ░   ░ ░ ░         ░░░ ░ ░   ░ ░    ░░░ ░ ░ ░  ░  ░      ░ ░     ░ ░      ░   ░  ░  ░   ░  ░░ ░");
        System.out.println(" ░  ░  ░    ░ ░         ░      ░              ░ ░ ░         ░         ░  ░   ░           ░                ░  ░   ░  ░      ░   ░  ░  ░");
        System.out.println("                                                ░                                                                                     ");
        System.out.println("                                           ██▓███   █    ██  ██▓███   ██▓███  ▓█████  ██▄▄█████▓▒                                         ");
        System.out.println("                                          ▓██░  ██▒ ██  ▓██▒▓██░  ██▒▓██░  ██▒▓█   ▀▓     ██▒  ▒                                         ");
        System.out.println("                                          ▓██░ ██▓▒▓██  ▒██░▓██░ ██▓▒▓██░ ██▓▒▒███  ▒    ▓██░  ▒░                                         ");
        System.out.println("                                          ▒██▄█▓▒ ▒▓▓█  ░██░▒██▄█▓▒ ▒▒██▄█▓▒ ▒▒▓█  ▄░    ▓██▓  ░                                          ");
        System.out.println("                                          ▒██▒ ░  ░▒▒█████▓ ▒██▒ ░  ░▒██▒ ░  ░░▒████▒    ▒██▒  ░                                          ");
        System.out.println("                                          ▒▓▒░ ░  ░░▒▓▒ ▒ ▒ ▒▓▒░ ░  ░▒▓▒░ ░  ░░░ ▒░ ░     ▒ ░░                                            ");
        System.out.println("                                          ░▒ ░     ░░▒░ ░ ░ ░▒ ░     ░▒ ░      ░ ░  ░      ░                                             ");
        System.out.println("                                          ░░        ░░░ ░ ░ ░░       ░░          ░        ░                                               ");
        System.out.println("                                                      ░                          ░  ░                                                 ");
        return "";
    }

    public static String endGame()
    {
        System.out.println("  ▄████  ▄▄▄       ███▄ ▄███▓▓█████     ▒█████   ██▒   █▓▓█████  ██▀███  ");
        System.out.println(" ██▒ ▀█▒▒████▄    ▓██▒▀█▀ ██▒▓█   ▀    ▒██▒  ██▒▓██░   █▒▓█   ▀ ▓██ ▒ ██▒");
        System.out.println("▒██░▄▄▄░▒██  ▀█▄  ▓██    ▓██░▒███      ▒██░  ██▒ ▓██  █▒░▒███   ▓██ ░▄█ ▒");
        System.out.println("░▓█  ██▓░██▄▄▄▄██ ▒██    ▒██ ▒▓█  ▄    ▒██   ██░  ▒██ █░░▒▓█  ▄ ▒██▀▀█▄  ");
        System.out.println("░▒▓███▀▒ ▓█   ▓██▒▒██▒   ░██▒░▒████▒   ░ ████▓▒░   ▒▀█░  ░▒████▒░██▓ ▒██▒");
        System.out.println(" ░▒   ▒  ▒▒   ▓▒█░░ ▒░   ░  ░░░ ▒░ ░   ░ ▒░▒░▒░    ░ ▐░  ░░ ▒░ ░░ ▒▓ ░▒▓░");
        System.out.println("  ░   ░   ▒   ▒▒ ░░  ░      ░ ░ ░  ░     ░ ▒ ▒░    ░ ░░   ░ ░  ░  ░▒ ░ ▒░");
        System.out.println("░ ░   ░   ░   ▒   ░      ░      ░      ░ ░ ░ ▒       ░░     ░     ░░   ░ ");
        System.out.println("      ░       ░  ░       ░      ░  ░       ░ ░        ░     ░  ░   ░     ");
        System.out.println("                                                     ░                   ");
        return "";
    }

    public static String oldTape(List<Animal> animals) throws InterruptedException
    {
        String msg = "";
        System.out.print("On the front of the tape, on the title line, it reads \n");
        delayDots(3);
        System.out.print("'Test no.1: collaborative play amongst specimens' \n");
        delayDots(3);
        System.out.print("You cram it into the tape player and hit the little triangle \n");
        delayDots(3);
        System.out.print("This tape shows a giant room");
        delayDots(3);

        for(Animal a : animals)
        {
            if( a instanceof Walking)
            {
                Walking w = (Walking)a;
                msg += a.getName() + ":     \n" + w.walk()  + "\n";
                if( a instanceof Flying)
                {
                    Flying f = (Flying)a;

                    msg += "     " + f.fly() + "\n";
                }
                if( a instanceof Swimming)
                {
                    Swimming s = (Swimming)a;

                    msg += "     " + s.swim() + "\n"     ;
                }
                if( a instanceof Spinning)
                {
                    Spinning sp = (Spinning)a;

                    msg += "     " + sp.spin() + "\n";
                }
                System.out.println("\n" + "\n");
            }
            else if( a instanceof Flying)
            {
                Flying f = (Flying)a;
                msg +=  a.getName() + ":     \n" + f.fly() + "\n";

                if( a instanceof Swimming)
                {
                    Swimming s = (Swimming)a;

                    msg += "     " + s.swim() + "\n";
                }
                if( a instanceof Spinning)
                {
                    Spinning sp = (Spinning)a;

                    msg += "     " + sp.spin() + "\n";
                }
                if( a instanceof Walking)
                {
                    Walking w = (Walking)a;

                    msg += "     " + w.walk() + "\n";
                }
            }
            else if( a instanceof Swimming)
            {
                Swimming s = (Swimming)a;
                msg += a.getName() + ":     \n" + s.swim()  + "\n";
                if( a instanceof Spinning)
                {
                    Spinning sp = (Spinning)a;

                    msg += "     " + sp.spin() + "\n";
                }
                if( a instanceof Walking)
                {
                    Walking w = (Walking)a;

                    msg += "     " + w.walk() + "\n";
                }
                if( a instanceof Flying)
                {
                    Flying f = (Flying)a;

                    msg += "     " + f.fly() + "\n";
                }
            }
            else if( a instanceof Spinning)
            {
                Spinning sp = (Spinning)a;
                msg += a.getName() + ":     \n" + sp.spin()  + "\n";
                if( a instanceof Walking)
                {
                    Walking w = (Walking)a;

                    msg += "     " + w.walk() + "\n";
                }
                if( a instanceof Flying)
                {
                    Flying f = (Flying)a;

                    msg += "     " + f.fly() + "\n";
                }
                if( a instanceof Swimming)
                {
                    Swimming s = (Swimming)a;

                    msg += "     " + s.swim() + "\n";
                }
            }
        }
        System.out.println(msg);
        return msg;
    }

    public static String intercomOn(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            msg += a.getName() + ": \n" + a.makeNoise() + "\n" + "\n";
        }
        return msg;
    }

    public static String zooBook(List<Animal> animals)
    {
        String msg = "";
        for(Animal a : animals)
        {
            System.out.println(a);
            System.out.println(a.eat());
            System.out.println(a.makeNoise());
            System.out.println();
        }
        return msg;
    }

    public static String exploreEnclosures(List<Animal> animals) throws InterruptedException
    {
        List<Animal> allMyAnimals = new ArrayList<Animal>();
        List<Researchers> allMyEmployees = new ArrayList<Researchers>();

        System.out.println("*> You enter under a massive, ornate, dome ceiling <* ");
        System.out.println("*> In front of you is a giant spiral staircase with a hallway <*");
        System.out.println("*> on either side. You see three signs; one for each entrance. <*");
        System.out.println("*> The signs read... <*");
        System.out.println("");
        System.out.println("++===========++  ++====================++  ++===========++");
        System.out.println("|| East Wing ||  || Falconry Tower   ↑ ||  || West Wing ||");
        System.out.println("||   Hall    ||  || Dungeon Chambers ↓ ||  ||   Hall    ||");
        System.out.println("++===========++  ++====================++  ++===========++");
        System.out.println("");
        System.out.println("Which path do you chose");                               
        delayDots(3);

        Scanner in = new Scanner(System.in);
        String text = in.nextLine();

        String msg = "";
        while(!text.equals("This game is garbonzo beans"))
        {
            switch(text)
            {
                case "East Wing Hall":
                msg = eastWing(allMyAnimals);
                break;

                case "West Wing Hall":
                msg = westWing(allMyAnimals);
                break;

                case "Falconry Tower":
                msg = falconryTower(allMyAnimals);
                break;

                case "Dungeon Chambers":
                msg = dungeonChambers(allMyAnimals);

                default : msg = "You flail helplessly with indecision";
            }
            break;
        }

        return "";
    }

    public static String eastWing(List<Animal> animals) throws InterruptedException
    {
        String msg = "";
        System.out.println("*>You start toward the left-most and least menacing entrance<*");
        System.out.println("*>This hall is lined with torches (most of which are still lit)<*");
        System.out.println("*>The taps of your shoes on cobblestone echo on the domed brick hall<*");
        System.out.println("*>You step out of the hall and eneter a room much like the last, ");
        System.out.println("however, more furnished and with tame, non-threatening animals roaming about.<*");
        System.out.println("*>To the right of you is a quaint wooden stand with a friendly-");
        System.out.println("plump old woman behind the counter.<*");
        delayDots();

        for(Animal a : animals)
        {
            if( a instanceof EastWing)
            {
                EastWing e = (EastWing)a;
                msg += a.getName() + ": \n" + e.east()  + "\n";
            }
        }

        System.out.println("*>Do you:<*");
        System.out.println("▷ Visit the counter");
        System.out.println("▷ Move forward");

        Scanner in = new Scanner(System.in);
        String text = in.nextLine();

        if(text.equals("Visit the counter"))
        {
            System.out.println("''Well hi there sweetie! My name's Betty. I'm the head");
            System.out.println("researcher of all things mild-mannered here at Oak's center. \n''");

            System.out.println("''Go Ahead and take a look at what I got in stock, honey.''");
            System.out.println("▷ Sure!");
            System.out.println("▷ No thank you");

            Scanner betty = new Scanner(System.in);
            String bettyResponse = in.nextLine();

            if(bettyResponse.equals("Sure!"))
            {
                System.out.println("Looks like all I got is a Holy Hand Grenade, sweety.");
                System.out.println("For you, Honey, I can let it go for 5 gold peices.");
                System.out.println("If you're short on cash, you can visit Prof. Oak's study;");
                System.out.println("He's always keeping little stashes of coins around there");
                System.out.println("\n▷ Buy");
                System.out.println("▷ Nevermind");

                Scanner buy = new Scanner(System.in);
                String buyResponse = in.nextLine();
                if(money >= 5)
                {

                    if(buyResponse.equals("Buy"))
                    {
                        money -= 5;
                        holyHandGrenade = true;
                        System.out.println("Thanks for the business sugar! Hope it serves you well!");
                        System.out.println("(The Holy Hand Grenade is a one time use item)");
                        System.out.println("(Thou must count to three to use this item and the number of counting shall be three)");
                        System.out.println("(Thou shall not count to four, nor shalt thou count to two unless thou then proceed to three)");
                        System.out.println("(Five is outright!)");
                        System.out.println("*>To use this item, just count 'one...two...three' and it will be thrown in a battle<*");
                        System.out.println("* Your wallet now holds " + money + " gold peices.");
                    }
                    else
                    {
                        System.out.println("Sorry i didn't have anything for you sweety");
                        System.out.println("I hope to see you agian sometime!");
                    }
                }
                else
                {
                    System.out.println("Sorry, sugar. I'm already losing money at 5 gp. You're welcome back any time when you get enough coin!");
                }

            }
            else
            {
                msg ="''Sorry to hear that hun - Come back any time okay?''";
            }
            in = new Scanner(System.in);
            text = in.nextLine();
            System.out.println("*>Please move forward*");
            System.out.println("▷ Move forward");
        }
        if(text.equals("Move forward"))
        {
            System.out.println("*> You walk foreward to the end of the giant ball room without trouble. You finally \n");
            System.out.print("reach a large door. The sign hanging on the right handle of the door reads");
            delayDots(3);
            System.out.println("++================================================++");
            System.out.println("|| Death awaits you with nasty, big, pointy teeth ||");
            System.out.println("||                      ,\\                        ||");
            System.out.println("||                       \\\\,_                     ||");
            System.out.println("||                        \\` ,\\                   ||");
            System.out.println("||                  __,.-'' =__)                  ||");
            System.out.println("||               .''        )                     ||");
            System.out.println("||            ,_/   ,    \\/\\_                     ||");
            System.out.println("||            \\_|    )_-\\ \\_-`                    ||");
            System.out.println("||               `-----` `--`                     ||");
            System.out.println("++================================================++");
            
            bunnyBoss();
            
        }
        else
        {
            System.out.println("*>You have no clue what to do<*");
        }

        return msg;
    }

    public static String westWing(List<Animal> animals) throws InterruptedException
    {
        String msg = "";

        for(Animal a : animals)
        {
            if( a instanceof WestWing)
            {
                WestWing w = (WestWing)a;
                msg += a.getName() + ": \n" + w.west()  + "\n";
            }
        }

        return msg;
    }

    public static String falconryTower(List<Animal> animals) throws InterruptedException
    {
        String msg = "";

        for(Animal a : animals)
        {
            if( a instanceof WestWing)
            {
                FalconryTower t = (FalconryTower)a;
                msg += a.getName() + ": \n" + t.tower()  + "\n";
            }
        }

        return msg;
    }

    public static String dungeonChambers(List<Animal> animals) throws InterruptedException
    {
        String msg = "";

        for(Animal a : animals)
        {
            if( a instanceof DungeonChambers)
            {
                DungeonChambers d = (DungeonChambers)a;
                msg += a.getName() + ": \n" + d.dungeon()  + "\n";
            }
        }

        return msg;
    }

    public static String bunnyBoss() throws InterruptedException
    {
        String msg = "";
        animalHp = 40;
        System.out.println("*>You crack the door open, and there, before you, sits a very cute a fluffy bunny.*>");
        System.out.println("*>You look closer, and realize that this rabit is sitting in a giant pool of blood.*>");
        System.out.println("*>Next to the rabit is the mangled carcass that looks nearly human in what appears"); 
        System.out.println("to be a shredded labcoat<*");
        delayDots(3);
        System.out.println("You shuffle, and the rabit notices you");
        delayDots(3); 
        System.out.println("It stares at you, waggling its nose");
        delayDots(3);
        System.out.println("There is a long, eerie silence, followed by an all out charge of fur and teeth toward your face");
        delayDots(3);
        System.out.println("What do you do?");
        System.out.println("▷ Kick");
        System.out.println("▷ Punch");
        if(holyHandGrenade = true)
        {
            System.out.println("▷ Use Holy Hand Grenade");
        }
        
        for(int i = 0; animalHp > i; i++)
        {
            Scanner in = new Scanner(System.in);
            String text = in.nextLine();
            if(text.equals("Use Holy Hand Grenade"))
            {
                animalHp -= 40;
            }
            if(text.equals("Kick"))
            {
                animalHp -= 20;
            }
            if(text.equals("Use Holy Hand Grenade"))
            {
                animalHp -= 10;
            }
        }
        if(animalHp <= 0)
        {
            msg = "*>Hurra hurra, the beast is dead!<*";
        }

        return msg;
    }
}
