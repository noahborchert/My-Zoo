
/**
 * Abstract class Animal - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public abstract class Animal
{
    protected String name;
    protected String description;
    
    public static int numAnimals = 0;
    
    public Animal()
    {
        // Call the other constructor that takes one String param
        // Passing in none of the name
        // This is called contructor chaining when of constructor 
        // calls another
        this("none");
    }
    
    public Animal(String name)
    {
        // Call the other constructor that takes two String params
        // Passing in the value referenced by the name variable and 
        // none for the description
        this(name, "none");
    }
    
    public Animal(String name, String description)
    {
        // Set the name and description for the animal
        this.name = name;
        this.description = description;
        // Increment the numAnimals indicating that another animal has
        // been created
        numAnimals++;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getName()
    {
        return this.name;
    }
    
    public void setDescription(String description)
    {
        this.description = description;
    }
    
    public String getDescription()
    {
        return this.description;
    }
    
    @Override
    
    public String toString()
    {
        return this.name + "; " + this.description;
    }
    
    public abstract String eat();
    
    public abstract String makeNoise();
    
}
