
/**
 * Write a description of interface WestWingPod here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface WestWing
{
    public String west() throws InterruptedException;
}
