
/**
 * Write a description of class Snake here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Bigfoot extends Animal implements Walking, WestWing
{
    public Bigfoot()
    {
        /*
         *  Call my other constructor that takes two Strings
         *  Again, this is called constructotr chaining
         */
        this("Alihondra the Bigfoot", "Lives in dense woods and kills trasspares on his territory");
    }
    
    public Bigfoot(String name, String description)
    {
        /*
         * super means call something in my parent class (Animal), in this
         * case I am calling the constructor in my aprent that takes
         * two paramenters and sending in the name and description that 
         * were passed into this constructor
         */
        
        
        super(name, description);
    }
    
    @Override
    public String eat()
    {
        return "Eats people";
    }
    
    @Override
    public String makeNoise()
    {
        return "AHHHwhabdbad RAAAAA aasdsafsrvs AHAHHAH afashdf";
    }
    
    @Override
    public String walk()
    {
        return "Boom Boom Boom";
    }
    
    @Override
    public String west()
    {
        return "every time you look at him hes in a different location, but always frozen in a walking position";
    }
}
