import java.util.concurrent.TimeUnit;
/**
 *ass
 */
public class Vincent extends Researchers implements FalconryTower
{

    /**
     * Construction for objects of class moblin
     */
    public Vincent()
    {
        this("Vince" , "Always impaired one way or another");
    }
    public Vincent(String name, String description)
    {
        super(name, description);
    }
    
    @Override
    public String job()
    {
        return "Head psychedelics researcher - Falconry Tower";
    }
    
    @Override
    public String talkTo() throws InterruptedException
    {
        System.out.print("'' /n Bro I can literally see the curvature of the Earth. This stuff is insane''");
        delayDots(3);
        return "";
    }
    
    @Override
    public String tower() throws InterruptedException
    {
        System.out.println("Head of research in the falconry tower");
        delayDots(3);
        return "";
    }
    
    
}
