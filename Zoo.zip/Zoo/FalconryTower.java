
/**
 * Write a description of interface BasementLevelPod here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface FalconryTower
{
    public String tower() throws InterruptedException;
}
