import java.util.concurrent.TimeUnit;
/**
 * Abstract class Pigeon - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public class Betty extends Researchers implements EastWing
{

    /**
     * Construction for objects of class moblin
     */
    public Betty()
    {
        this("Betty" , "If you didn't know any better you would think she were a baker");
    }
    public Betty(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String job()
    {
        return "Head Management - East Wing";
    }
    
    @Override
    public String talkTo() throws InterruptedException
    {
        return "''My job is very fluffy''";
    }
    
    @Override
    public String east()
    {
        return "Head of the cutest and tamest wing of the castle";
    }
}
