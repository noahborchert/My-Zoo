
/**
 * Abstract class Llama - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public class Llama extends Animal implements EastWing
{
    /**
     * Construction for objects of class Llama
     */
    public Llama()
    {
        this("Laverne the Llama" , "Shirley's best friend");
        
    }
    
    /**
     * Llama Constructor
     *
     * @param name A parameter
     * @param description A parameter
     */
    public Llama(String name, String description) {
        super(name, description);
    }
    
    @Override 
    public String eat()
    {
        return "Pellets";
    }
    
    @Override
    public String makeNoise()
    {
        return "hummm-screee";
    }
    
    @Override
    public String east()
    {
        return "arrogantly prancing around";
    }
}

