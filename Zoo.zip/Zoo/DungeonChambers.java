
/**
 * Write a description of interface BasementLevelPod here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface DungeonChambers
{
    public String dungeon() throws InterruptedException;
}
