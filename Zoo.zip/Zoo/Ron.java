import java.util.concurrent.TimeUnit;
/**
 * Abstract class Pigeon - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public class Ron extends Researchers implements WestWing
{

    /**
     * Construction for objects of class moblin
     */
    public Ron()
    {
        this("Ron" , "Masters degree in curling into a fetal ball and crying in the face of danger");
    }
    public Ron(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String job()
    {
        return "Handy-man and panic engineer - West Wing";
    }
    
    @Override
    public String talkTo() throws InterruptedException
    {
        return "''I have several degrees in the field of panicking''";
    }
    
    @Override
    public String west()
    {
        return "Head of the mild-yet-dangerous wing, and doing nothing to contain the chaos.";
    }
}
