
/**
 * Write a description of class phish here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Phish extends Animal implements Swimming, EastWing
{
    /**
     * Constructor for objects of class phish
     */
    public Phish()
    {
        this("Terarius the phish", " He has a PhD in swim.");
    }
    public Phish(String name, String description)
    {
        super(name, description);
    }
    @Override
    public String eat()
    {
        return "TS-1 jet fuel";
    }
    @Override
    public String makeNoise()
    {
        return "blubs intelligently";
    }
    @Override
    public String swim()
    {
       return "";
    }
    @Override
    public String east()
    {
        return "blubbing about in the fountain";
    }
}