
/**
 * Write a description of interface EastWingPod here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface EastWing
{
    public String east();
}
